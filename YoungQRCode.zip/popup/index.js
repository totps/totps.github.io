
// $(document).ready(function(){
//
// });

document.addEventListener('DOMContentLoaded', function(){

    }
)

document.getElementById("div_4f4f304df351399a").style.display = "none";
document.getElementById('btn_1d6d674ccd66716a').onclick = function () {
    // alert($('#copy_text').text())
    // 创建input元素，给input传值，将input放入html里，选择input
    var w = document.createElement('input');
    w.value = document.getElementById('text_cab651968dd311b0').innerText;
    document.body.appendChild(w);
    w.select();
    // 调用浏览器的复制命令
    document.execCommand("Copy");
    // 将input元素隐藏，通知操作完成！
    w.style.display='none';
    document.execCommand("copy");
    document.getElementById("copy_ac36a6b8bb732a66").style.opacity = 1;
    setTimeout('document.getElementById("copy_ac36a6b8bb732a66").style.opacity = 0', 1000);
}

document.getElementById('btn_e30c0932817c0ce8').onclick = function () {
    document.getElementById("div_4f4f304df351399a").style.display = "none";
}