﻿console.log('这是content script!');

// 注意，必须设置了run_at=document_start 此段代码才会生效
document.addEventListener('DOMContentLoaded', function()
{

	// 注入自定义JS
	//injectCustomJs();
    initCustomPanel();
    if(!window.jQuery){
        injectCustomJs('popup/jquery-3.5.1.min.js');
	}
    injectCustomJs('popup/index.js');
});

function initCustomPanel()
{
	var panel = document.createElement('div');
	panel.className = 'youngDialog';
	panel.innerHTML = `
	<div  id="div_4f4f304df351399a" style="position: fixed;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0,0,0,.5);z-index: 999;display: none;" >
	<div  style="position:absolute;width:600px;background:#fff;border-radius:4px;z-index:21;top:15%;left:50%;transform:translate(-50%);">
		<div id="btn_e30c0932817c0ce8" style="font-family: 'Microsoft YaHei', 'PingFang SC', 'Helvetica Neue', 'Hiragino Sans GB', 'Noto Sans', Tahoma, 'Arial', 'simsun', 'sans-serif';position:absolute;right:20px;top:14px;color:#999;font-size:14px;cursor:pointer;user-select:none;font-size:15px;">×</div>
		<div style="margin-top:40px;margin-bottom:20px;text-align:center;font-size:18px;color:rgba(55,55,55,1);">
	解码结果
		</div>
		<div style="background:rgba(247,249,247,1);border-radius:4px;margin:24px;padding:12px 16px;">
			<div  id="text_cab651968dd311b0" style="white-space: pre-wrap;:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;">https://qr.alipay.com/fkx10826t    zhctpaezvjc0e0</div>
		</div>
		<div style="text-align: center;position: relative;">
			<!--<button class="op-generate btn">生成二维码</button>-->
		<button id="btn_1d6d674ccd66716a" style="margin-left: 8px;height:32px;line-height:1;padding:0;width:118px;font-size:14px;	background-color:#4caf50;color:rgba(255,255,255,1);font-weight:500;outline:0!important;border-width:0;">复制</button>
		<!--<span class="scan-again">再次扫描</span>-->
		</div>
		<div id="copy_ac36a6b8bb732a66" style="text-align:center;color:#999;font-size:12px;margin-top:11px;margin-bottom:12px;opacity:1;user-select:none;">
			<span>复制成功</span>
		</div>
	</div>
</div>
	`;
	document.body.appendChild(panel);
}

// 向页面注入JS
function injectCustomJs(jsPath)
{
	jsPath = jsPath || 'popup/index.js';
    console.log("injectJS:" + jsPath);
	var temp = document.createElement('script');
	temp.setAttribute('type', 'text/javascript');
	// 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
	temp.src = chrome.extension.getURL(jsPath);
	temp.onload = function()
	{// 放在页面不好看，执行完后移除掉
		this.parentNode.removeChild(this);
	};
	document.body.appendChild(temp);
}
chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        document.getElementById("text_cab651968dd311b0").innerText = request;
        document.getElementById("div_4f4f304df351399a").style.display = "block";

    }
);