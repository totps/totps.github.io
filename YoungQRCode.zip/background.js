//-------------------- 右键菜单演示 ------------------------//


chrome.contextMenus.create({
    title: "赞赏开发者",
    contexts: ["page_action"],
    onclick: () => {
        chrome.windows.create({
            url: chrome.runtime.getURL("popup/sk.png"),
            width: 493,
            height: 298,
            type: "popup",
            state: 'normal',
        }, function (win) {
            chrome.windows.update(win.id, { focused: true });
        });
    }
});
chrome.contextMenus.create({
    title: "联系开发者",
    contexts: ["page_action"],
    onclick: () => {
        alert("QQ:584036\nmail:power5455@163.com")
    }
});
chrome.contextMenus.create({
	title:chrome.i18n.getMessage("menuName"),
    contexts:["image"],
	onclick: function(info, tab){
		console.log("background.html");
		console.log(JSON.stringify(tab));
	    QrScanner.WORKER_PATH = 'qrcode/qr-scanner-worker.min.js';
        QrScanner.scanImage(info.srcUrl)
    .then(result => {
        chrome.tabs.sendMessage(tab.id, result);
        // chrome.browserAction.setPopup({popup: 'popup/index.html'})
        // chrome.windows.create({
        //     url: chrome.runtime.getURL("popup/index.html"),
        //     width: 800,
        //     height: 620,
        //     top: 0,
        //     type: "popup",
        //     state: 'normal',
        //     setSelfAsOpener:true
        // }, function (win) {
        //     chrome.windows.update(win.id, { focused: true });
        // });
    //alert(result);
    })
    .catch(error => {
    console.log(error || 'No QR code found.');
    alert(error || 'No QR code found.');
    });
	}
});
